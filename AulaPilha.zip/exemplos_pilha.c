#include <stdio.h>
#include "pilha.h"

// Função para imprimir uma pilha
void imprime(TPilha *p){
    TPilha *aux;
    aux = inicializa(aux);

    while(!vazia(p)) {
        int info = pop(p);
        printf("%d\n", info);
        push(aux, info);
    }

    // Pilha p sai da função igual entrou
    while(!vazia(aux)){
        push(p, pop(aux));
    }
}

int verificaMaiorElementodaPilha(TPilha *p){

}

int main(){

    TPilha *p;
    p = inicializa(p);
    /*if(vazia(p)){
        printf("PILHA VAZIA!!");
    } else {
        printf("PILHA NÂO ESTÁ VAZIA!!!");
    }*/

    push(p, 10);
    push(p, 20);
    push(p, 40);
    push(p, 15);
    push(p, 25);
    push(p, 5);

    imprime(p);

    

    /*int x = pop(p);
    printf("Valor Removido da Pilha %d\n", x);
    x = pop(p);
    printf("Valor Removido da Pilha %d\n", x);
    x = pop(p);
    printf("Valor Removido da Pilha %d\n", x);*/
    
}