#include <stdio.h>
#include "fila.h"

void imprime(TFila *f){
    TFila *aux;
    aux = inicializa(aux);

    while(!vazia(f)) {
        int info = remover(f);
        printf("%d\n", info);
        inserir(aux, info);
    }

    // Fila f sai da função igual entrou
    while(!vazia(aux)){
        int info = remover(aux);
        inserir(f, info);
    }
}

int vericaMaiorElementodaFila(TFila *f){
    if(vazia(f)){
        return -1;
    }

    TFila *aux;
    aux = inicializa(aux);
    int maior = remover(f);
    while (!vazia(f)){
        int info = remover(f);
        if(info > maior){
            maior = info;
        }
        inserir(aux, info);
    }

    // Fila f sai da função igual entrou
    while(!vazia(aux)){
        int info = remover(aux);
        inserir(f, info);
    }
    return maior;
}

int main(){

    TFila *f;
    f = inicializa(f);

    inserir(f, 10);
    inserir(f, 20);
    inserir(f, 40);
    inserir(f, 30);

    imprime(f);

    printf("MAIOR ELEMENTO DA FILA %d\n", vericaMaiorElementodaFila(f));
    printf("MAIOR ELEMENTO DA FILA %d\n", vericaMaiorElementodaFila(f));
}